from manim import *

class BlueCircle(Scene):
    def construct(self):
        circle = Circle(radius=1.5, color=BLUE, fill_opacity=0.5)
        self.play(Create(circle))
        self.play(circle.animate.scale(1.3), run_time=1)
        self.play(circle.animate.scale(1/1.3), run_time=1)
        self.wait(1)
        print("MEDIA_DIR:", config.media_dir)
